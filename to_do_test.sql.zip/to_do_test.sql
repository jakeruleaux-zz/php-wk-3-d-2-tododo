-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Jul 18, 2017 at 01:48 AM
-- Server version: 5.6.35
-- PHP Version: 7.0.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `to_do_test`
--
CREATE DATABASE IF NOT EXISTS `to_do_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `to_do_test`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `categories_tasks`
--

CREATE TABLE `categories_tasks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `task_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categories_tasks`
--

INSERT INTO `categories_tasks` (`id`, `category_id`, `task_id`) VALUES
(2, 52, 95),
(3, 53, 96),
(4, 53, 97),
(6, 55, 110),
(7, 56, 111),
(8, 57, 111),
(10, 71, 113),
(11, 72, 114),
(12, 72, 115),
(14, 74, 128),
(15, 75, 129),
(16, 76, 129),
(18, 90, 131),
(19, 91, 132),
(20, 91, 133),
(22, 93, 146),
(23, 94, 147),
(24, 95, 147),
(26, 14, 2),
(27, 15, 3),
(28, 15, 4),
(30, 17, 17),
(31, 18, 18),
(32, 19, 18),
(34, 33, 20),
(35, 34, 21),
(36, 34, 22),
(38, 36, 35),
(39, 37, 36),
(40, 38, 36),
(42, 52, 38),
(43, 53, 39),
(44, 53, 40),
(46, 55, 53),
(47, 56, 54),
(48, 57, 54),
(50, 71, 56),
(51, 72, 57),
(52, 72, 58),
(54, 74, 71),
(55, 75, 72),
(56, 76, 72),
(58, 90, 74),
(59, 91, 75),
(60, 91, 76),
(62, 93, 89),
(63, 94, 90),
(64, 95, 90),
(66, 109, 92),
(67, 110, 93),
(68, 110, 94),
(70, 112, 107),
(71, 113, 108),
(72, 114, 108),
(74, 128, 110),
(75, 129, 111),
(76, 129, 112),
(78, 131, 125),
(79, 132, 126),
(80, 133, 126),
(83, 261, 129),
(84, 262, 130),
(85, 262, 131),
(87, 280, 133),
(88, 281, 134),
(89, 281, 135),
(91, 300, 137),
(92, 301, 138),
(93, 301, 139),
(95, 320, 141),
(96, 321, 142),
(97, 321, 143),
(99, 340, 146),
(100, 341, 147),
(101, 341, 148),
(103, 360, 151),
(104, 361, 152),
(105, 361, 153),
(107, 380, 157),
(108, 381, 158),
(109, 381, 159),
(111, 400, 164),
(112, 401, 165),
(113, 401, 166),
(115, 420, 173),
(116, 421, 174),
(117, 421, 175),
(119, 440, 184),
(120, 441, 185),
(121, 441, 186),
(124, 460, 196),
(125, 461, 197),
(126, 461, 198),
(129, 480, 210),
(130, 481, 211),
(131, 481, 212),
(134, 500, 225),
(135, 501, 226),
(136, 501, 227),
(139, 520, 242),
(140, 521, 243),
(141, 521, 244),
(143, 524, 258),
(145, 540, 260),
(146, 541, 261),
(147, 541, 262),
(149, 544, 276),
(150, 545, 277),
(151, 546, 277),
(153, 560, 279),
(154, 561, 280),
(155, 561, 281),
(157, 564, 295),
(158, 565, 296),
(159, 566, 296),
(161, 580, 298),
(162, 581, 299),
(163, 581, 300),
(165, 584, 314),
(166, 585, 315),
(167, 586, 315),
(169, 600, 317),
(170, 601, 318),
(171, 601, 319),
(173, 604, 333),
(174, 605, 334),
(175, 606, 334);

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `description` varchar(255) DEFAULT NULL,
  `id` bigint(20) UNSIGNED NOT NULL,
  `due_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=607;
--
-- AUTO_INCREMENT for table `categories_tasks`
--
ALTER TABLE `categories_tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=176;
--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=335;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
